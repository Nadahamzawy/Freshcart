import { TermTextPipe } from './term-text.pipe';

describe('TermTextPipe', () => {
  it('create an instance', () => {
    const pipe = new TermTextPipe();
    expect(pipe).toBeTruthy();
  });
});
