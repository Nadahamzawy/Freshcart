import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-notfounded',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './notfounded.component.html',
  styleUrl: './notfounded.component.scss'
})
export class NotfoundedComponent {

}
