export const environment= {
    baseUrl:`https://ecommerce.routemisr.com`,
    urlServer: `http://localhost:4200`
}